package com.MarryMate.servlets;

import com.MarryMate.models.Vendor;
import com.MarryMate.services.VendorManagementService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.LinkedList;

/**
 * Servlet for vendor management operations
 * Current Date and Time: 2025-05-06 08:27:00
 * Current User: IT24102137
 */
@WebServlet(urlPatterns = {
    "/VendorManagementServlet", 
    "/VendorManagementServlet/*", 
    "/admin/VendorManagementServlet",
    "/admin/VendorManagementServlet/*"
})
public class VendorManagementServlet extends HttpServlet {
    
    private VendorManagementService vendorService;
    private Gson gson;
    private final String vendorsFilePath = "H:\\SLIIT\\Sem 2\\OOP Project 01\\MarryMate\\src\\main\\webapp\\WEB-INF\\data\\vendors.json";
    
    @Override
    public void init() throws ServletException {
        super.init();
        vendorService = new VendorManagementService(vendorsFilePath);
        gson = new GsonBuilder().setPrettyPrinting().create();
    }
    
    /**
     * Handles GET requests for vendors
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // Check if this is a specific endpoint
            String pathInfo = request.getPathInfo();
            if (pathInfo != null) {
                handleGetWithPathInfo(request, response, pathInfo, out);
                return;
            }
            
            // Check if this is a request for a specific vendor
            String vendorId = request.getParameter("vendorId");
            if (vendorId != null && !vendorId.isEmpty()) {
                Vendor vendor = vendorService.getVendorById(vendorId);
                if (vendor != null) {
                    out.print(gson.toJson(vendor));
                } else {
                    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    out.print(createErrorJson("Vendor not found with ID: " + vendorId));
                }
                return;
            }
            
            // Check if this is a request for pending vendors
            String status = request.getParameter("status");
            if (status != null && status.equals("pending")) {
                LinkedList<Vendor> pendingVendors = vendorService.getPendingVendors();
                out.print(gson.toJson(pendingVendors));
                return;
            }
            
            // Otherwise, get filtered vendors list
            String category = request.getParameter("category");
            String search = request.getParameter("search");
            String featured = request.getParameter("featured");
            String dateRange = request.getParameter("dateRange");
            
            LinkedList<Vendor> filteredVendors = vendorService.filterVendors(
                status, category, search, featured, dateRange);
            
            out.print(gson.toJson(filteredVendors));
            
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(createErrorJson("Error processing request: " + e.getMessage()));
        }
    }
    
    /**
     * Handles POST requests for creating vendors and other operations
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            // Check if this is a specific endpoint
            String pathInfo = request.getPathInfo();
            if (pathInfo != null) {
                handlePostWithPathInfo(request, response, pathInfo, out);
                return;
            }
            
            // Regular vendor creation
            StringBuilder requestBody = getRequestBody(request);
            
            HttpSession session = request.getSession();
            String currentUser = (String) session.getAttribute("username");
            if (currentUser == null) {
                currentUser = "system"; // Default if not logged in
            }
            
            Vendor vendor = gson.fromJson(requestBody.toString(), Vendor.class);
            Vendor createdVendor = vendorService.createVendor(vendor, currentUser);
            
            response.setStatus(HttpServletResponse.SC_CREATED);
            out.print(gson.toJson(createdVendor));
            
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print(createErrorJson("Error processing request: " + e.getMessage()));
        }
    }
    
    /**
     * Handles PUT requests for updating vendors
     */
    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            StringBuilder requestBody = getRequestBody(request);
            
            HttpSession session = request.getSession();
            String currentUser = (String) session.getAttribute("username");
            if (currentUser == null) {
                currentUser = "system"; // Default if not logged in
            }
            
            Vendor vendor = gson.fromJson(requestBody.toString(), Vendor.class);
            
            if (vendor.getUserId() == null || vendor.getUserId().isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(createErrorJson("Vendor ID is required for updates"));
                return;
            }
            
            Vendor updatedVendor = vendorService.updateVendor(vendor, currentUser);
            out.print(gson.toJson(updatedVendor));
            
        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.print(createErrorJson(e.getMessage()));
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print(createErrorJson("Error processing request: " + e.getMessage()));
        }
    }
    
    /**
     * Handles DELETE requests for removing vendors
     */
    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        try {
            String vendorId = request.getParameter("vendorId");
            
            if (vendorId == null || vendorId.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(createErrorJson("Vendor ID is required for deletion"));
                return;
            }
            
            boolean deleted = vendorService.deleteVendor(vendorId);
            
            if (deleted) {
                JsonObject result = new JsonObject();
                result.addProperty("success", true);
                result.addProperty("message", "Vendor deleted successfully");
                out.print(result.toString());
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.print(createErrorJson("Vendor not found with ID: " + vendorId));
            }
            
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(createErrorJson("Error processing request: " + e.getMessage()));
        }
    }
    
    /**
     * Handle GET requests with path info
     */
    private void handleGetWithPathInfo(HttpServletRequest request, HttpServletResponse response, 
                                      String pathInfo, PrintWriter out) throws IOException {
        // Handle export request
        if (pathInfo.equals("/export")) {
            handleExport(request, response, out);
            return;
        }
        
        // Path not recognized
        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
        out.print(createErrorJson("Endpoint not found: " + pathInfo));
    }
    
    /**
     * Handle POST requests with path info
     */
    private void handlePostWithPathInfo(HttpServletRequest request, HttpServletResponse response, 
                                       String pathInfo, PrintWriter out) throws IOException {
        HttpSession session = request.getSession();
        String currentUser = (String) session.getAttribute("username");
        if (currentUser == null) {
            currentUser = "system"; // Default if not logged in
        }
        
        // Handle approve request
        if (pathInfo.equals("/approve")) {
            handleApprove(request, response, out, currentUser);
            return;
        }
        
        // Handle reject request
        if (pathInfo.equals("/reject")) {
            handleReject(request, response, out, currentUser);
            return;
        }
        
        // Handle bulk action request
        if (pathInfo.equals("/bulk")) {
            handleBulkAction(request, response, out, currentUser);
            return;
        }
        
        // Path not recognized
        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
        out.print(createErrorJson("Endpoint not found: " + pathInfo));
    }
    
    /**
     * Handle vendor approval
     */
    private void handleApprove(HttpServletRequest request, HttpServletResponse response, 
                              PrintWriter out, String currentUser) throws IOException {
        try {
            StringBuilder requestBody = getRequestBody(request);
            JsonObject jsonRequest = gson.fromJson(requestBody.toString(), JsonObject.class);
            
            String vendorId = jsonRequest.has("vendorId") ? jsonRequest.get("vendorId").getAsString() : null;
            
            if (vendorId == null || vendorId.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(createErrorJson("Vendor ID is required for approval"));
                return;
            }
            
            Vendor vendor = vendorService.approveVendor(vendorId, currentUser);
            
            JsonObject result = new JsonObject();
            result.addProperty("success", true);
            result.addProperty("message", "Vendor approved successfully");
            result.add("vendor", gson.toJsonTree(vendor));
            out.print(result.toString());
            
        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.print(createErrorJson(e.getMessage()));
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(createErrorJson("Error processing request: " + e.getMessage()));
        }
    }
    
    /**
     * Handle vendor rejection
     */
    private void handleReject(HttpServletRequest request, HttpServletResponse response, 
                             PrintWriter out, String currentUser) throws IOException {
        try {
            StringBuilder requestBody = getRequestBody(request);
            JsonObject jsonRequest = gson.fromJson(requestBody.toString(), JsonObject.class);
            
            String vendorId = jsonRequest.has("vendorId") ? jsonRequest.get("vendorId").getAsString() : null;
            
            if (vendorId == null || vendorId.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(createErrorJson("Vendor ID is required for rejection"));
                return;
            }
            
            Vendor vendor = vendorService.rejectVendor(vendorId, currentUser);
            
            JsonObject result = new JsonObject();
            result.addProperty("success", true);
            result.addProperty("message", "Vendor rejected successfully");
            result.add("vendor", gson.toJsonTree(vendor));
            out.print(result.toString());
            
        } catch (IllegalArgumentException e) {
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            out.print(createErrorJson(e.getMessage()));
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(createErrorJson("Error processing request: " + e.getMessage()));
        }
    }
    
    /**
     * Handle bulk actions on vendors
     */
    private void handleBulkAction(HttpServletRequest request, HttpServletResponse response, 
                                 PrintWriter out, String currentUser) throws IOException {
        try {
            StringBuilder requestBody = getRequestBody(request);
            JsonObject jsonRequest = gson.fromJson(requestBody.toString(), JsonObject.class);
            
            String action = jsonRequest.has("action") ? jsonRequest.get("action").getAsString() : null;
            JsonArray vendorIdsArray = jsonRequest.has("vendorIds") ? jsonRequest.getAsJsonArray("vendorIds") : null;
            
            if (action == null || action.isEmpty() || vendorIdsArray == null) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(createErrorJson("Action and vendorIds are required for bulk operations"));
                return;
            }
            
            List<String> vendorIds = new ArrayList<>();
            vendorIdsArray.forEach(id -> vendorIds.add(id.getAsString()));
            
            int affectedCount = vendorService.performBulkAction(action, vendorIds, currentUser);
            
            JsonObject result = new JsonObject();
            result.addProperty("success", true);
            result.addProperty("message", "Bulk action completed successfully");
            result.addProperty("affectedCount", affectedCount);
            out.print(result.toString());
            
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(createErrorJson("Error processing request: " + e.getMessage()));
        }
    }
    
    /**
     * Handle vendor data export
     */
    private void handleExport(HttpServletRequest request, HttpServletResponse response, 
                             PrintWriter out) throws IOException {
        try {
            String format = request.getParameter("format");
            
            if (format == null || format.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print(createErrorJson("Export format is required"));
                return;
            }
            
            // Get filtered vendors for export
            String status = request.getParameter("status");
            String category = request.getParameter("category");
            String search = request.getParameter("search");
            String featured = request.getParameter("featured");
            String dateRange = request.getParameter("dateRange");
            
            LinkedList<Vendor> filteredVendors = vendorService.filterVendors(
                status, category, search, featured, dateRange);
            
            switch (format.toLowerCase()) {
                case "csv":
                    response.setContentType("text/csv");
                    response.setHeader("Content-Disposition", "attachment; filename=\"vendors.csv\"");
                    out.print(vendorService.exportToCsv(filteredVendors));
                    break;
                case "excel":
                    response.setContentType("application/vnd.ms-excel");
                    response.setHeader("Content-Disposition", "attachment; filename=\"vendors.xlsx\"");
                    out.print(vendorService.exportToCsv(filteredVendors));
                    break;
                case "pdf":
                    // In a real application, you would generate a PDF here
                    response.setContentType("application/pdf");
                    response.setHeader("Content-Disposition", "attachment; filename=\"vendors.pdf\"");
                    // This is a placeholder - actual PDF generation would require additional libraries
                    out.print("PDF export not implemented in this example");
                    break;
                default:
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    out.print(createErrorJson("Unsupported export format: " + format));
            }
            
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print(createErrorJson("Error processing export: " + e.getMessage()));
        }
    }
    
    /**
     * Get request body as string
     * @param request HTTP request
     * @return StringBuilder containing request body
     * @throws IOException if an I/O error occurs
     */
    private StringBuilder getRequestBody(HttpServletRequest request) throws IOException {
        StringBuilder buffer = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            buffer.append(line);
        }
        return buffer;
    }
    
    /**
     * Create error JSON object
     * @param message Error message
     * @return JSON string with error message
     */
    private String createErrorJson(String message) {
        JsonObject error = new JsonObject();
        error.addProperty("error", true);
        error.addProperty("message", message);
        return error.toString();
    }
}