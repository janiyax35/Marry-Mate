package com.MarryMate.services;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.ServletContext;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.MarryMate.models.Vendor;

/**
 * Service class to manage vendor-related operations
 * Current Date and Time: 2025-05-11 17:25:46
 * Current User: IT24102083
 */
public class VendorManagementService {
    
    // File paths for JSON data storage
    private static final String VENDORS_FILE_PATH = "H:\\SLIIT\\Sem 2\\OOP Project 01\\MarryMate\\src\\main\\webapp\\WEB-INF\\data\\vendors.json";
    private static final String VENDOR_SERVICES_FILE_PATH = "H:\\SLIIT\\Sem 2\\OOP Project 01\\MarryMate\\src\\main\\webapp\\WEB-INF\\vendorServices.json";
    private static final String SERVICE_CATEGORIES_FILE_PATH = "H:\\SLIIT\\Sem 2\\OOP Project 01\\MarryMate\\src\\main\\webapp\\WEB-INF\\data\\service-categories.json";
    
    // GSON for JSON serialization/deserialization
    private Gson gson;
    
    // Singleton instance
    private static VendorManagementService instance;
    
    // ServletContext for file operations
    private ServletContext servletContext;
    
    /**
     * Get the singleton instance of VendorManagementService
     * @param servletContext ServletContext for file operations
     * @return VendorManagementService instance
     */
    public static synchronized VendorManagementService getInstance(ServletContext servletContext) {
        if (instance == null) {
            instance = new VendorManagementService(servletContext);
        }
        return instance;
    }
    
    /**
     * Private constructor to enforce singleton pattern
     * @param servletContext ServletContext for file operations
     */
    private VendorManagementService(ServletContext servletContext) {
        this.servletContext = servletContext;
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        
        // Initialize files if they don't exist
        initializeFiles();
    }
    
    /**
     * Initialize necessary JSON files if they don't exist
     */
    private void initializeFiles() {
        // Initialize vendors.json
        File vendorsFile = new File(VENDORS_FILE_PATH);
        if (!vendorsFile.exists()) {
            try {
                vendorsFile.getParentFile().mkdirs();
                JsonObject root = new JsonObject();
                root.add("vendors", new JsonArray());
                try (FileWriter writer = new FileWriter(vendorsFile)) {
                    writer.write(gson.toJson(root));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        // Initialize vendorServices.json
        File servicesFile = new File(VENDOR_SERVICES_FILE_PATH);
        if (!servicesFile.exists()) {
            try {
                servicesFile.getParentFile().mkdirs();
                try (FileWriter writer = new FileWriter(servicesFile)) {
                    writer.write("[]");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        // Initialize service-categories.json
        File categoriesFile = new File(SERVICE_CATEGORIES_FILE_PATH);
        if (!categoriesFile.exists()) {
            try {
                categoriesFile.getParentFile().mkdirs();
                JsonArray categories = new JsonArray();
                
                // Add default categories
                String[] defaultCategories = {
                    "photography", "videography", "catering", "venues", "decoration", 
                    "entertainment", "planning", "beauty", "transportation", "attire",
                    "jewelry", "invitations", "gifts", "flowers", "rental", "cake", "honeymoon"
                };
                
                for (String category : defaultCategories) {
                    JsonObject categoryObj = new JsonObject();
                    categoryObj.addProperty("name", category);
                    categoryObj.addProperty("active", true);
                    categoryObj.addProperty("serviceCount", 0);
                    categories.add(categoryObj);
                }
                
                try (FileWriter writer = new FileWriter(categoriesFile)) {
                    writer.write(gson.toJson(categories));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Get all vendor services for a specific vendor
     * @param vendorId The vendor ID to get services for
     * @return List of services as JSON objects
     */
    public JsonArray getVendorServices(String vendorId) {
        JsonArray result = new JsonArray();
        
        try {
            // Read the vendorServices.json file
            File file = new File(VENDOR_SERVICES_FILE_PATH);
            if (!file.exists()) {
                return result;
            }
            
            JsonArray allServices;
            try (FileReader reader = new FileReader(file)) {
                // Check if the file is empty
                reader.mark(1);
                int firstChar = reader.read();
                reader.reset();
                
                if (firstChar == -1) {
                    // File is empty
                    return result;
                }
                
                // Parse the file content
                JsonElement parsed = JsonParser.parseReader(reader);
                if (parsed.isJsonArray()) {
                    allServices = parsed.getAsJsonArray();
                } else if (parsed.isJsonObject() && parsed.getAsJsonObject().has("services")) {
                    allServices = parsed.getAsJsonObject().getAsJsonArray("services");
                } else {
                    // Unexpected format
                    return result;
                }
            }
            
            // Filter services by vendorId
            for (JsonElement element : allServices) {
                if (element.isJsonObject()) {
                    JsonObject service = element.getAsJsonObject();
                    if (service.has("vendorId") && service.get("vendorId").getAsString().equals(vendorId)) {
                        result.add(service);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return result;
    }
    
    /**
     * Add a new service for a vendor
     * @param vendorId The vendor ID to add the service for
     * @param service The service details as a JSON object
     * @return The added service with generated ID and timestamps
     */
    public JsonObject addService(String vendorId, JsonObject service) {
        try {
            // Read existing services
            JsonArray services = readVendorServices();
            
            // Generate the next service ID
            String nextServiceId = generateNextServiceId(services);
            
            // Add required fields to the service
            service.addProperty("id", nextServiceId);
            service.addProperty("vendorId", vendorId);
            
            // Add timestamps
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String currentDateTime = sdf.format(new Date());
            service.addProperty("createdAt", currentDateTime);
            service.addProperty("updatedAt", currentDateTime);
            
            // Add the new service
            services.add(service);
            
            // Write updated services back to file
            writeVendorServices(services);
            
            // Update vendor's serviceIds
            updateVendorServiceIds(vendorId, nextServiceId, true);
            
            // Update service category count
            if (service.has("category")) {
                updateServiceCategoryCount(service.get("category").getAsString(), 1);
            }
            
            return service;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Update an existing service
     * @param vendorId The vendor ID
     * @param serviceId The service ID to update
     * @param updatedService The updated service details
     * @return The updated service or null if not found or unauthorized
     */
    public JsonObject updateService(String vendorId, String serviceId, JsonObject updatedService) {
        try {
            // Read existing services
            JsonArray services = readVendorServices();
            String oldCategory = null;
            
            // Find and update the service
            for (int i = 0; i < services.size(); i++) {
                JsonObject service = services.get(i).getAsJsonObject();
                
                if (service.has("id") && service.get("id").getAsString().equals(serviceId)) {
                    // Check if the service belongs to the vendor
                    if (!service.has("vendorId") || !service.get("vendorId").getAsString().equals(vendorId)) {
                        return null; // Unauthorized
                    }
                    
                    // Save the old category
                    if (service.has("category")) {
                        oldCategory = service.get("category").getAsString();
                    }
                    
                    // Preserve required fields
                    updatedService.addProperty("id", serviceId);
                    updatedService.addProperty("vendorId", vendorId);
                    
                    // Update timestamp
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    updatedService.addProperty("updatedAt", sdf.format(new Date()));
                    
                    // Preserve creation timestamp
                    if (service.has("createdAt")) {
                        updatedService.addProperty("createdAt", service.get("createdAt").getAsString());
                    }
                    
                    // Replace the service
                    services.set(i, updatedService);
                    
                    // Update service category counts if category changed
                    if (oldCategory != null && updatedService.has("category")) {
                        String newCategory = updatedService.get("category").getAsString();
                        if (!oldCategory.equals(newCategory)) {
                            updateServiceCategoryCount(oldCategory, -1);
                            updateServiceCategoryCount(newCategory, 1);
                        }
                    }
                    
                    // Write updated services back to file
                    writeVendorServices(services);
                    
                    return updatedService;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null; // Service not found
    }
    
    /**
     * Delete a service
     * @param vendorId The vendor ID
     * @param serviceId The service ID to delete
     * @return true if deleted successfully, false otherwise
     */
    public boolean deleteService(String vendorId, String serviceId) {
        try {
            // Read existing services
            JsonArray services = readVendorServices();
            String serviceCategory = null;
            
            // Find and remove the service
            for (int i = 0; i < services.size(); i++) {
                JsonObject service = services.get(i).getAsJsonObject();
                
                if (service.has("id") && service.get("id").getAsString().equals(serviceId)) {
                    // Check if the service belongs to the vendor
                    if (!service.has("vendorId") || !service.get("vendorId").getAsString().equals(vendorId)) {
                        return false; // Unauthorized
                    }
                    
                    // Save the category before removing
                    if (service.has("category")) {
                        serviceCategory = service.get("category").getAsString();
                    }
                    
                    // Remove the service
                    services.remove(i);
                    
                    // Write updated services back to file
                    writeVendorServices(services);
                    
                    // Update service category count
                    if (serviceCategory != null) {
                        updateServiceCategoryCount(serviceCategory, -1);
                    }
                    
                    // Remove serviceId from vendor
                    updateVendorServiceIds(vendorId, serviceId, false);
                    
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false; // Service not found
    }
    
    /**
     * Get all service categories
     * @return List of service categories as JSON objects
     */
    public JsonArray getServiceCategories() {
        try {
            File file = new File(SERVICE_CATEGORIES_FILE_PATH);
            if (!file.exists()) {
                return new JsonArray();
            }
            
            try (FileReader reader = new FileReader(file)) {
                return JsonParser.parseReader(reader).getAsJsonArray();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new JsonArray();
        }
    }
    
    /**
     * Get vendor details by ID
     * @param vendorId The vendor ID
     * @return The vendor details as a JSON object or null if not found
     */
    public JsonObject getVendorById(String vendorId) {
        try {
            // Read vendors.json
            File file = new File(VENDORS_FILE_PATH);
            if (!file.exists()) {
                return null;
            }
            
            try (FileReader reader = new FileReader(file)) {
                JsonObject vendorsJson = JsonParser.parseReader(reader).getAsJsonObject();
                JsonArray vendors = vendorsJson.getAsJsonArray("vendors");
                
                for (JsonElement element : vendors) {
                    JsonObject vendor = element.getAsJsonObject();
                    if (vendor.has("userId") && vendor.get("userId").getAsString().equals(vendorId)) {
                        return vendor;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null; // Vendor not found
    }
    
    // Helper methods
    
    /**
     * Read the vendorServices.json file
     * @return JsonArray containing all services
     */
    private JsonArray readVendorServices() {
        JsonArray services = new JsonArray();
        File jsonFile = new File(VENDOR_SERVICES_FILE_PATH);
        
        if (jsonFile.exists()) {
            try (FileReader reader = new FileReader(jsonFile)) {
                // Check if the file is empty
                reader.mark(1);
                int firstChar = reader.read();
                reader.reset();
                
                if (firstChar == -1) {
                    // File is empty, return an empty array
                    return services;
                }
                
                // Try to parse as array first
                JsonElement parsed = JsonParser.parseReader(reader);
                if (parsed.isJsonArray()) {
                    services = parsed.getAsJsonArray();
                } else if (parsed.isJsonObject()) {
                    // If it's an object, try to get services array from it
                    JsonObject jsonObject = parsed.getAsJsonObject();
                    if (jsonObject.has("services")) {
                        services = jsonObject.getAsJsonArray("services");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                // Return empty array on error
                services = new JsonArray();
            }
        }
        
        return services;
    }
    
    /**
     * Write services to vendorServices.json file
     * @param services The services to write
     */
    private void writeVendorServices(JsonArray services) {
        try (FileWriter writer = new FileWriter(VENDOR_SERVICES_FILE_PATH)) {
            gson.toJson(services, writer);
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Generate the next service ID
     * @param services Current services array
     * @return The next service ID
     */
    private String generateNextServiceId(JsonArray services) {
        int maxId = 1000; // Start with S1001
        
        // Find the highest existing service ID
        for (int i = 0; i < services.size(); i++) {
            JsonObject service = services.get(i).getAsJsonObject();
            if (service.has("id")) {
                String serviceId = service.get("id").getAsString();
                if (serviceId.startsWith("S") && serviceId.length() > 1) {
                    try {
                        int idNum = Integer.parseInt(serviceId.substring(1));
                        if (idNum > maxId) {
                            maxId = idNum;
                        }
                    } catch (NumberFormatException e) {
                        // Ignore non-numeric IDs
                    }
                }
            }
        }
        
        // Create the next service ID
        return "S" + (maxId + 1);
    }
    
    /**
     * Update the service count for a category in service-categories.json
     * @param category The category name
     * @param increment The amount to increment by (1 for add, -1 for delete)
     */
    private void updateServiceCategoryCount(String category, int increment) {
        if (category == null || category.isEmpty()) {
            return;
        }
        
        try {
            // Read the service-categories.json file
            JsonArray categories = new JsonArray();
            File file = new File(SERVICE_CATEGORIES_FILE_PATH);
            
            if (file.exists()) {
                try (FileReader reader = new FileReader(file)) {
                    categories = JsonParser.parseReader(reader).getAsJsonArray();
                } catch (Exception e) {
                    e.printStackTrace();
                    // If parsing fails, create a new array
                    categories = new JsonArray();
                }
            }
            
            // Find the category and update its count
            boolean categoryExists = false;
            
            for (int i = 0; i < categories.size(); i++) {
                JsonObject categoryObj = categories.get(i).getAsJsonObject();
                if (categoryObj.has("name") && categoryObj.get("name").getAsString().equals(category)) {
                    int currentCount = categoryObj.has("serviceCount") ? 
                            categoryObj.get("serviceCount").getAsInt() : 0;
                    
                    // Update count (ensure it doesn't go below 0)
                    int newCount = Math.max(0, currentCount + increment);
                    categoryObj.addProperty("serviceCount", newCount);
                    
                    categoryExists = true;
                    break;
                }
            }
            
            // If category doesn't exist, add it (only for new services)
            if (!categoryExists && increment > 0) {
                JsonObject newCategory = new JsonObject();
                newCategory.addProperty("name", category);
                newCategory.addProperty("active", true);
                newCategory.addProperty("serviceCount", 1);
                categories.add(newCategory);
            }
            
            // Write updated data back to service-categories.json
            try (FileWriter writer = new FileWriter(file)) {
                gson.toJson(categories, writer);
                writer.flush();
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Update the serviceIds array for a vendor in vendors.json
     * @param vendorId The vendor ID
     * @param serviceId The service ID
     * @param add True to add, false to remove
     */
    private void updateVendorServiceIds(String vendorId, String serviceId, boolean add) {
        if (vendorId == null || vendorId.isEmpty() || serviceId == null || serviceId.isEmpty()) {
            return;
        }
        
        try {
            // Read the vendors.json file
            JsonObject vendorsJson = new JsonObject();
            JsonArray vendors = new JsonArray();
            File file = new File(VENDORS_FILE_PATH);
            
            if (file.exists()) {
                try (FileReader reader = new FileReader(file)) {
                    vendorsJson = JsonParser.parseReader(reader).getAsJsonObject();
                    if (vendorsJson.has("vendors")) {
                        vendors = vendorsJson.getAsJsonArray("vendors");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    // If parsing fails, create new structure
                    vendorsJson = new JsonObject();
                    vendors = new JsonArray();
                    vendorsJson.add("vendors", vendors);
                }
            } else {
                vendorsJson.add("vendors", vendors);
            }
            
            // Find the vendor and update serviceIds
            for (int i = 0; i < vendors.size(); i++) {
                JsonObject vendor = vendors.get(i).getAsJsonObject();
                if (vendor.has("userId") && vendor.get("userId").getAsString().equals(vendorId)) {
                    JsonArray serviceIds;
                    
                    // Get existing serviceIds or create new array
                    if (vendor.has("serviceIds")) {
                        serviceIds = vendor.getAsJsonArray("serviceIds");
                    } else {
                        serviceIds = new JsonArray();
                    }
                    
                    if (add) {
                        // Add serviceId if it doesn't already exist
                        boolean exists = false;
                        for (int j = 0; j < serviceIds.size(); j++) {
                            if (serviceIds.get(j).getAsString().equals(serviceId)) {
                                exists = true;
                                break;
                            }
                        }
                        
                        if (!exists) {
                            serviceIds.add(serviceId);
                        }
                    } else {
                        // Remove serviceId if it exists
                        JsonArray updatedServiceIds = new JsonArray();
                        for (int j = 0; j < serviceIds.size(); j++) {
                            if (!serviceIds.get(j).getAsString().equals(serviceId)) {
                                updatedServiceIds.add(serviceIds.get(j));
                            }
                        }
                        serviceIds = updatedServiceIds;
                    }
                    
                    // Update vendor with new serviceIds array
                    vendor.add("serviceIds", serviceIds);
                    
                    // Update timestamp
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    vendor.addProperty("updatedAt", sdf.format(new Date()));
                    
                    break;
                }
            }
            
            // Write updated data back to vendors.json
            try (FileWriter writer = new FileWriter(file)) {
                gson.toJson(vendorsJson, writer);
                writer.flush();
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}